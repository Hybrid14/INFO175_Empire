![alt text](http://i.imgur.com/tfUqRni.png)
![alt text](http://i.imgur.com/5wUKVS6.png)
![alt text](http://i.imgur.com/Lysjvga.png)
![alt text](http://i.imgur.com/Is9YR5X.png)



