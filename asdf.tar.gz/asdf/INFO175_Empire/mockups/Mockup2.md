![alt text](http://i.imgur.com/Tpfuo9x.png)
![alt text](http://i.imgur.com/NuEVn5Fg.png)
![alt text](http://i.imgur.com/MwyBBXT.png)
![alt text](http://i.imgur.com/qZbI5cq.png)
![alt text](http://i.imgur.com/JcmQCDH.png)
![alt text](http://i.imgur.com/03LCasf.png)






